const rows = [["—","No official results yet","—","—"]];
document.getElementById("players-body").innerHTML = rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("");