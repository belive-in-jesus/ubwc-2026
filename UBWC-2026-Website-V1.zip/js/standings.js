const rows = [
  ["—","No official results yet","—","—","PRE-EVENT"],
];
document.getElementById("standings-body").innerHTML = rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join("")}</tr>`).join("");